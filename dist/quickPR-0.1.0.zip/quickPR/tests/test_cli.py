import contextlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from quickpr.cli import main, select_local, resolve_token
from quickpr.errors import QuickPRError
from quickpr.files import git_blob_sha
from quickpr.github import Snapshot


class TerminalAPI:
    token = "test-token"
    repo = "owner/repo"

    def __init__(self):
        self.writes = []
        self.refs = {"main": "old-head"}

    def snapshot(self, branch=None):
        return Snapshot(branch or "main", "old-head", "root", True)

    def head(self, branch):
        return self.refs[branch]

    def request(self, method, path, data=None):
        if method == "GET" and path == "/git/trees/root":
            return {"sha": "root", "truncated": False, "tree": [
                {"path": "same.txt", "type": "blob", "mode": "100644", "sha": "ce013625030ba8dba906f756967f9e9ca394464a"},
                {"path": "keep.txt", "type": "blob", "mode": "100644", "sha": "keep-sha"}]}
        self.writes.append((method, path, data))
        if path == "/git/blobs":
            import base64
            return {"sha": git_blob_sha(base64.b64decode(data["content"]))}
        if path == "/git/trees":
            return {"sha": "new-tree"}
        if path == "/git/commits":
            return {"sha": "new-head"}
        if path == "/git/refs/heads/main":
            self.refs["main"] = data["sha"]
            return {"object": {"sha": data["sha"]}}
        raise AssertionError((method, path))


class CLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.file = self.root / "中文 空格.txt"
        self.file.write_text("new content", encoding="utf-8")
        self.api = TerminalAPI()

    def run_cli(self, args, answers=()):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output), \
                patch("quickpr.cli.resolve_token", return_value="test-token"), \
                patch("quickpr.cli.GitHub", return_value=self.api), \
                patch("builtins.input", side_effect=list(answers) if answers else EOFError):
            code = main(args)
        return code, output.getvalue()

    def test_dry_run_previews_mapping_without_writes(self):
        code, output = self.run_cli(["upload", str(self.file), "--repo", "owner/repo", "--dest", "docs", "--dry-run"])
        self.assertEqual(code, 0)
        self.assertIn("docs/中文 空格.txt", output)
        self.assertEqual(self.api.writes, [])

    def test_yes_upload_publishes_one_commit_and_prints_link(self):
        code, output = self.run_cli(["upload", str(self.file), "--repo", "owner/repo", "--yes"])
        self.assertEqual(code, 0)
        self.assertEqual(self.api.refs["main"], "new-head")
        self.assertIn("https://github.com/owner/repo/commit/new-head", output)
        self.assertEqual(len([w for w in self.api.writes if w[1] == "/git/commits"]), 1)

    def test_declining_confirmation_causes_zero_writes(self):
        code, output = self.run_cli(["upload", str(self.file), "--repo", "owner/repo"], ["n"])
        self.assertEqual(code, 0)
        self.assertEqual(self.api.writes, [])

    def test_noninteractive_upload_requires_explicit_yes(self):
        code, output = self.run_cli(["upload", str(self.file), "--repo", "owner/repo"])
        self.assertNotEqual(code, 0)
        self.assertEqual(self.api.writes, [])

    def test_tree_command_is_read_only(self):
        code, output = self.run_cli(["tree", "owner/repo", "--depth", "1"])
        self.assertEqual(code, 0)
        self.assertIn("keep.txt", output)
        self.assertEqual(self.api.writes, [])

    def test_tree_failure_returns_error_code(self):
        code, output = self.run_cli(["tree", "owner/repo", "--path", "absent"])
        self.assertEqual(code, 1)

    def test_full_interactive_wizard_selects_previews_and_uploads(self):
        code, output = self.run_cli([], ["1", "owner/repo", "", str(self.root), "all", "done", "", "", "", "y"])
        self.assertEqual(code, 0, output)
        self.assertEqual(self.api.refs["main"], "new-head")
        self.assertIn("上传预览", output)
        self.assertIn("中文 空格.txt", output)

    def test_no_changes_skip_commit_and_confirmation(self):
        same = self.root / "same.txt"
        same.write_bytes(b"hello\n")
        code, output = self.run_cli(["upload", str(same), "--repo", "owner/repo"])
        self.assertEqual(code, 0)
        self.assertIn("无需上传", output)
        self.assertEqual(self.api.writes, [])

    def test_local_picker_navigates_and_selects_file(self):
        sub = self.root / "folder"
        sub.mkdir()
        child = sub / "picked.txt"
        child.write_text("x", encoding="utf-8")
        with contextlib.redirect_stdout(io.StringIO()), patch("builtins.input", side_effect=["cd 1", "1", "done"]):
            paths, root = select_local(self.root)
        self.assertEqual(paths, [child])
        self.assertEqual(root, self.root)

    def test_local_picker_all_selects_root_and_quit_cancels(self):
        with contextlib.redirect_stdout(io.StringIO()), patch("builtins.input", side_effect=["all", "done"]):
            paths, root = select_local(self.root)
        self.assertEqual(paths, [self.root])
        with contextlib.redirect_stdout(io.StringIO()), patch("builtins.input", return_value="q"):
            paths, root = select_local(self.root)
        self.assertEqual(paths, [])

    def test_env_token_has_priority_over_gh_and_is_not_printed(self):
        with patch.dict(os.environ, {"GH_TOKEN": " from-env ", "GITHUB_TOKEN": "other"}, clear=True), \
                patch("quickpr.cli.subprocess.run") as run:
            self.assertEqual(resolve_token(), "from-env")
            run.assert_not_called()

    def test_gh_timeout_does_not_hang_public_browsing(self):
        with patch.dict(os.environ, {}, clear=True), patch("quickpr.cli.shutil.which", return_value="gh"), \
                patch("quickpr.cli.subprocess.run", side_effect=subprocess.TimeoutExpired("gh", 10)):
            self.assertIsNone(resolve_token())

    def test_module_help_works_without_credentials(self):
        result = subprocess.run([sys.executable, "-m", "quickpr", "--help"], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("upload", result.stdout)
        self.assertIn("tree", result.stdout)


if __name__ == "__main__":
    unittest.main()
