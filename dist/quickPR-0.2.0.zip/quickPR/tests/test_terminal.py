import io
import os
import unittest

from quickpr.terminal import Terminal, clip_text, decode_key


class TerminalTests(unittest.TestCase):
    def test_macos_arrow_sequences_and_windows_extended_keys(self):
        pairs = [("\x1b[A", "up"), ("\x1b[B", "down"), ("\x1b[C", "right"), ("\x1b[D", "left"),
                 ("\x1bOA", "up"), ("\xe0H", "up"), ("\xe0P", "down"), ("\xe0M", "right"), ("\x00K", "left"),
                 ("\r", "enter"), ("\n", "enter"), (" ", "enter"), ("F", "f"), ("\x1b", "escape")]
        for raw, expected in pairs:
            with self.subTest(raw=raw):
                self.assertEqual(decode_key(raw), expected)

    def test_control_c_becomes_interrupt(self):
        with self.assertRaises(KeyboardInterrupt):
            decode_key("\x03")

    def test_clip_counts_chinese_columns_and_escapes_controls(self):
        self.assertEqual(clip_text("中文abc", 6), "中文a…")
        self.assertEqual(clip_text("a\x1bb\n", 30), "a\\u001bb\\u000a")

    def test_redraw_replaces_rows_without_scroll_or_newlines(self):
        output = io.StringIO()
        terminal = Terminal(stdout=output)
        terminal.render(["before", "second row"])
        first = output.getvalue()
        terminal.render(["after"])
        second = output.getvalue()[len(first):]
        self.assertIn("\x1b[1;1H", second)
        self.assertIn("after", second)
        self.assertNotIn("\n", second)
        self.assertIn("\x1b[2K", second)

    @unittest.skipIf(os.name == "nt", "POSIX terminal integration")
    def test_real_terminal_keys_and_input_mode_restore_after_error(self):
        import pty
        import termios
        master, slave = pty.openpty()
        self.addCleanup(os.close, master)
        stream = os.fdopen(slave, "r", encoding="utf-8")
        self.addCleanup(stream.close)
        before = termios.tcgetattr(stream.fileno())
        output = io.StringIO()
        with self.assertRaisesRegex(RuntimeError, "stop"):
            with Terminal(stdin=stream, stdout=output) as terminal:
                os.write(master, b"\x1b[B\r\x1bOC")
                self.assertEqual(terminal.read_key(), "down")
                self.assertEqual(terminal.read_key(), "enter")
                self.assertEqual(terminal.read_key(), "right")
                raise RuntimeError("stop")
        after = termios.tcgetattr(stream.fileno())
        # macOS may set PENDIN when restoring canonical input after reading;
        # this kernel-maintained reprint flag is not a user input-mode change.
        after[3] &= ~getattr(termios, "PENDIN", 0)
        before[3] &= ~getattr(termios, "PENDIN", 0)
        self.assertEqual(after, before)
        self.assertEqual(output.getvalue().count("\x1b[?1049h"), 1)
        self.assertTrue(output.getvalue().endswith("\x1b[0m\x1b[?25h\x1b[?1049l"))


if __name__ == "__main__":
    unittest.main()
