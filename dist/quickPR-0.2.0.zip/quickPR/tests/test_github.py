import io
import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from quickpr.errors import APIError, NetworkError, QuickPRError
from quickpr.github import GitHub, RemoteTree, parse_repo, validate_branch


class Reply(io.BytesIO):
    def __init__(self, data):
        super().__init__(json.dumps(data).encode())


class Transport:
    def __init__(self, response):
        self.response = response
        self.requests = []

    def open(self, request, timeout):
        self.requests.append(request)
        if isinstance(self.response, Exception):
            raise self.response
        return Reply(self.response)


class GitHubTests(unittest.TestCase):
    def test_repo_address_forms(self):
        for value in ["owner/repo", "https://github.com/owner/repo", "https://github.com/owner/repo.git/", "git@github.com:owner/repo.git"]:
            self.assertEqual(parse_repo(value), "owner/repo")

    def test_repo_rejects_credentials_extra_paths_and_foreign_hosts(self):
        for value in ["https://github.com.evil.test/o/r", "https://user:token@github.com/o/r", "o/r/tree/main", "https://github.com/o/r?token=x", "../repo", "https://github.com/o/r#x"]:
            with self.subTest(value=value), self.assertRaises(QuickPRError):
                parse_repo(value)

    def test_branch_names_allow_slashes_and_reject_invalid_git_refs(self):
        self.assertEqual(validate_branch("feature/中文"), "feature/中文")
        for value in ["-x", "a..b", "a.lock", "a/.b", "a@{b", "a b", "a\\b", "a//b", "a/", "a."]:
            with self.subTest(value=value), self.assertRaises(QuickPRError):
                validate_branch(value)

    def test_auth_and_json_sent_to_fixed_github_api(self):
        transport = Transport({"sha": "new"})
        api = GitHub("o/r", "test-secret", opener=transport)
        result = api.request("POST", "/git/trees", {"base_tree": "old", "tree": []})
        self.assertEqual(result["sha"], "new")
        request = transport.requests[0]
        self.assertEqual(request.full_url, "https://api.github.com/repos/o/r/git/trees")
        self.assertEqual(request.get_header("Authorization"), "Bearer test-secret")
        self.assertEqual(json.loads(request.data), {"base_tree": "old", "tree": []})

    def test_http_error_hides_token_even_if_server_echoes_it(self):
        error = HTTPError("https://api.github.com", 403, "Forbidden", {}, io.BytesIO(b'{"message":"test-secret denied"}'))
        api = GitHub("o/r", "test-secret", opener=Transport(error))
        with self.assertRaises(APIError) as ctx:
            api.request("GET", "")
        self.assertNotIn("test-secret", str(ctx.exception))
        self.assertEqual(ctx.exception.status, 403)

    def test_network_errors_are_distinct_from_definite_api_errors(self):
        api = GitHub("o/r", opener=Transport(URLError("offline")))
        with self.assertRaises(NetworkError):
            api.request("GET", "")

    def test_invalid_json_is_handled_as_uncertain_response(self):
        class Invalid:
            def open(self, request, timeout):
                return io.BytesIO(b"<html>proxy error</html>")
        with self.assertRaises(NetworkError):
            GitHub("o/r", opener=Invalid()).request("GET", "")

    def test_lazy_tree_lookup_fetches_only_required_subdirectory_once(self):
        class API:
            def __init__(self):
                self.paths = []
            def request(self, method, path):
                self.paths.append(path)
                return {"sha": "x", "truncated": False, "tree": (
                    [{"path": "docs", "type": "tree", "mode": "040000", "sha": "docs-sha"},
                     {"path": "huge", "type": "tree", "mode": "040000", "sha": "huge-sha"}]
                    if path == "/git/trees/root" else
                    [{"path": "a.txt", "type": "blob", "mode": "100644", "sha": "file-sha"}])}
        api = API()
        tree = RemoteTree(api, "root")
        self.assertEqual(tree.lookup("docs/a.txt")["sha"], "file-sha")
        self.assertIsNone(tree.lookup("docs/missing.txt"))
        self.assertIsNone(tree.lookup("missing/x"))
        self.assertEqual(api.paths, ["/git/trees/root", "/git/trees/docs-sha"])

    def test_incomplete_tree_refuses_to_guess_missing_files(self):
        class API:
            def request(self, method, path):
                return {"tree": [], "truncated": True}
        with self.assertRaises(QuickPRError):
            RemoteTree(API(), "root").lookup("a.txt")

    def test_tree_walk_honors_depth(self):
        class API:
            def request(self, method, path):
                return {"truncated": False, "tree": [
                    {"path": "docs", "type": "tree", "mode": "040000", "sha": "d"},
                    {"path": "a.txt", "type": "blob", "mode": "100644", "sha": "f"},
                ]}
        rows = list(RemoteTree(API(), "root").walk(depth=1))
        self.assertEqual([r[0] for r in rows], ["docs", "a.txt"])

    def test_snapshot_reads_default_branch_commit_tree_and_permissions(self):
        api = GitHub("o/r")
        with patch.object(api, "request", side_effect=[
            {"default_branch": "main", "permissions": {"push": True}},
            {"object": {"sha": "head"}}, {"tree": {"sha": "root"}},
        ]):
            result = api.snapshot()
        self.assertEqual((result.branch, result.head, result.tree_sha, result.can_push), ("main", "head", "root", True))

    def test_empty_repository_gets_actionable_error(self):
        api = GitHub("o/r")
        with patch.object(api, "request", side_effect=[{"default_branch": "main"}, APIError(409, "empty")]):
            with self.assertRaises(QuickPRError) as ctx:
                api.snapshot()
        self.assertIn("README", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
