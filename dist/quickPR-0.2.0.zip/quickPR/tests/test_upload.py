import base64
from pathlib import Path
import unittest

from quickpr.errors import APIError, NetworkError, QuickPRError
from quickpr.files import Change, LocalFile
from quickpr.github import Snapshot
from quickpr.upload import publish


class FakeGitHub:
    """External API substitute; record requests to verify wire contracts."""
    repo = "owner/repo"
    token = "test-token"

    def __init__(self):
        self.head_value = "old-head"
        self.refs = {"main": "old-head"}
        self.writes = []
        self.failure = None
        self.head_reads = 0
        self.change_on_second_read = False

    def head(self, branch):
        self.head_reads += 1
        if self.change_on_second_read and self.head_reads == 2:
            self.refs["main"] = "someone-else"
        if branch not in self.refs:
            raise APIError(404, "missing")
        return self.refs[branch]

    def request(self, method, path, data=None):
        self.writes.append((method, path, data))
        if path == "/git/blobs":
            return {"sha": "ce013625030ba8dba906f756967f9e9ca394464a"}
        if path == "/git/trees":
            return {"sha": "new-tree"}
        if path == "/git/commits":
            return {"sha": "new-commit"}
        if path.startswith("/git/refs"):
            if self.failure == "rejected":
                raise APIError(422, "protected")
            if self.failure == "lost":
                raise NetworkError("lost response")
            branch = data.get("ref", "refs/heads/main").removeprefix("refs/heads/")
            self.refs[branch] = data["sha"]
            if self.failure == "response-lost-after-success":
                raise NetworkError("lost response")
            return {"object": {"sha": data["sha"]}}
        raise AssertionError(path)


class UploadTests(unittest.TestCase):
    def setUp(self):
        self.api = FakeGitHub()
        self.snapshot = Snapshot("main", "old-head", "old-tree", True)
        f = LocalFile(Path("a.txt"), "docs/a.txt", b"hello\n", "ce013625030ba8dba906f756967f9e9ca394464a", "100644")
        self.change = Change(f, "update", "100755")

    def test_atomic_publish_preserves_base_tree_and_uses_one_nonforced_commit(self):
        result = publish(self.api, self.snapshot, [self.change], "Upload files")
        self.assertEqual(result.sha, "new-commit")
        writes = self.api.writes
        self.assertEqual(base64.b64decode(writes[0][2]["content"]), b"hello\n")
        self.assertEqual(writes[1][2], {"base_tree": "old-tree", "tree": [
            {"path": "docs/a.txt", "mode": "100755", "type": "blob", "sha": "ce013625030ba8dba906f756967f9e9ca394464a"}]})
        self.assertEqual(writes[2][2], {"message": "Upload files", "tree": "new-tree", "parents": ["old-head"]})
        self.assertEqual(writes[3], ("PATCH", "/git/refs/heads/main", {"sha": "new-commit", "force": False}))

    def test_unchanged_files_produce_no_write(self):
        self.assertIsNone(publish(self.api, self.snapshot, [Change(self.change.file, "skip", "100644")], "noop"))
        self.assertEqual(self.api.writes, [])

    def test_stale_preview_causes_zero_writes(self):
        self.api.refs["main"] = "new-head"
        with self.assertRaises(QuickPRError):
            publish(self.api, self.snapshot, [self.change], "x")
        self.assertEqual(self.api.writes, [])

    def test_concurrent_change_during_blob_upload_never_updates_branch(self):
        self.api.change_on_second_read = True
        with self.assertRaises(QuickPRError):
            publish(self.api, self.snapshot, [self.change], "x")
        self.assertFalse(any(w[1].startswith("/git/refs") for w in self.api.writes))

    def test_new_branch_is_created_at_complete_commit_without_touching_source(self):
        result = publish(self.api, self.snapshot, [self.change], "x", new_branch="uploads/new")
        self.assertEqual(result.branch, "uploads/new")
        self.assertEqual(self.api.refs["main"], "old-head")
        self.assertEqual(self.api.writes[-1], ("POST", "/git/refs", {"ref": "refs/heads/uploads/new", "sha": "new-commit"}))

    def test_existing_new_branch_is_not_overwritten(self):
        self.api.refs["exists"] = "existing"
        with self.assertRaises(QuickPRError):
            publish(self.api, self.snapshot, [self.change], "x", new_branch="exists")
        self.assertEqual(self.api.writes, [])

    def test_lost_success_response_is_reconciled_by_reading_ref(self):
        self.api.failure = "response-lost-after-success"
        self.assertEqual(publish(self.api, self.snapshot, [self.change], "x").sha, "new-commit")
        self.assertEqual(len(self.api.writes), 4)

    def test_unconfirmed_network_result_includes_commit_for_manual_check(self):
        self.api.failure = "lost"
        with self.assertRaises(QuickPRError) as ctx:
            publish(self.api, self.snapshot, [self.change], "x")
        self.assertIn("https://github.com/owner/repo/commit/new-commit", str(ctx.exception))
        self.assertEqual(self.api.refs["main"], "old-head")

    def test_protected_branch_error_does_not_retry_or_force(self):
        self.api.failure = "rejected"
        with self.assertRaises(QuickPRError):
            publish(self.api, self.snapshot, [self.change], "x")
        self.assertEqual(self.api.refs["main"], "old-head")
        self.assertEqual(len([w for w in self.api.writes if w[0] == "PATCH"]), 1)

    def test_missing_write_permission_fails_before_upload(self):
        self.snapshot = Snapshot("main", "old-head", "old-tree", False)
        with self.assertRaises(QuickPRError):
            publish(self.api, self.snapshot, [self.change], "x")
        self.assertEqual(self.api.writes, [])


if __name__ == "__main__":
    unittest.main()
