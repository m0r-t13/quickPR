"""Exercise the real CLI and HTTP serialization against local Git objects.

Only the network is substituted. Git's actual object database verifies that
our base-tree/commit/ref payloads retain untouched files and binary contents.
No GitHub account or external writes are involved.
"""

import base64
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import unquote, urlsplit

from quickpr.cli import main
from quickpr.github import GitHub


class GitTransport:
    def __init__(self, path):
        self.path = path
        self.env = dict(os.environ, GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
                        GIT_AUTHOR_NAME="quickPR Test", GIT_AUTHOR_EMAIL="test@example.invalid",
                        GIT_COMMITTER_NAME="quickPR Test", GIT_COMMITTER_EMAIL="test@example.invalid")
        for key in ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"):
            self.env.pop(key, None)
        self.git("init", "--bare", "--quiet")

    def git(self, *args, data=None):
        return subprocess.run(["git", "--git-dir", str(self.path), *args], input=data,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=self.env, check=True).stdout

    def text(self, *args, data=None):
        return self.git(*args, data=data).decode("utf-8").strip()

    def write_blob(self, data):
        return self.text("hash-object", "-w", "--stdin", data=data)

    def initial_commit(self):
        self.git("read-tree", "--empty")
        for path, content in [("docs/change.txt", b"old"), ("docs/keep.txt", b"do not delete"), ("same.txt", b"hello\n")]:
            sha = self.write_blob(content)
            self.git("update-index", "--add", "--cacheinfo", "100644", sha, path)
        tree = self.text("write-tree")
        commit = self.text("commit-tree", tree, data=b"Initial fixture\n")
        self.git("update-ref", "refs/heads/main", commit)
        return commit

    def open(self, request, timeout):
        suffix = unquote(urlsplit(request.full_url).path.removeprefix("/repos/test/repo"))
        payload = json.loads(request.data) if request.data else None
        if request.method == "GET":
            if suffix == "":
                result = {"default_branch": "main", "permissions": {"push": True}}
            elif suffix.startswith("/git/ref/heads/"):
                branch = suffix.removeprefix("/git/ref/heads/")
                result = {"object": {"sha": self.text("rev-parse", "refs/heads/" + branch)}}
            elif suffix.startswith("/git/commits/"):
                result = {"tree": {"sha": self.text("rev-parse", suffix.rsplit("/", 1)[1] + "^{tree}")}}
            elif suffix.startswith("/git/trees/"):
                rows = self.git("ls-tree", "-z", suffix.rsplit("/", 1)[1]).split(b"\0")
                entries = []
                for row in rows:
                    if row:
                        metadata, path = row.split(b"\t", 1)
                        mode, kind, sha = metadata.decode("ascii").split()
                        entries.append({"path": path.decode("utf-8"), "mode": mode, "type": kind, "sha": sha})
                result = {"tree": entries, "truncated": False}
            else:
                raise AssertionError(suffix)
        elif suffix == "/git/blobs":
            result = {"sha": self.write_blob(base64.b64decode(payload["content"]))}
        elif suffix == "/git/trees":
            self.git("read-tree", payload["base_tree"])
            for entry in payload["tree"]:
                self.git("update-index", "--add", "--cacheinfo", entry["mode"], entry["sha"], entry["path"])
            result = {"sha": self.text("write-tree")}
        elif suffix == "/git/commits":
            result = {"sha": self.text("commit-tree", payload["tree"], "-p", payload["parents"][0], data=payload["message"].encode())}
        elif suffix.startswith("/git/refs/heads/"):
            if payload["force"]:
                raise AssertionError("Unexpected force update")
            ref = "refs/heads/" + suffix.removeprefix("/git/refs/heads/")
            old = self.text("rev-parse", ref)
            self.git("merge-base", "--is-ancestor", old, payload["sha"])
            self.git("update-ref", ref, payload["sha"], old)
            result = {"object": {"sha": payload["sha"]}}
        else:
            raise AssertionError((request.method, suffix))
        return io.BytesIO(json.dumps(result).encode("utf-8"))


@unittest.skipUnless(shutil.which("git"), "Optional Git object integration test requires git")
class GitIntegrationTests(unittest.TestCase):
    def test_cli_changes_two_files_preserves_sibling_and_makes_one_commit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            remote = root / "remote.git"
            transport = GitTransport(remote)
            original = transport.initial_commit()
            local = root / "local"
            (local / "docs").mkdir(parents=True)
            (local / "docs" / "change.txt").write_bytes(b"updated\r\n")
            (local / "new 中文.bin").write_bytes(b"\x00\xff\x80\r\n")
            (local / "same.txt").write_bytes(b"hello\n")
            api = GitHub("test/repo", "fake-token", opener=transport)
            output = io.StringIO()
            with patch("quickpr.cli.GitHub", return_value=api), patch("quickpr.cli.resolve_token", return_value="fake-token"), contextlib.redirect_stdout(output):
                code = main(["upload", str(local), "--repo", "test/repo", "--yes"])
            self.assertEqual(code, 0, output.getvalue())
            self.assertEqual(transport.text("rev-list", "--count", "main"), "2")
            self.assertEqual(transport.text("rev-parse", "main^"), original)
            self.assertEqual(transport.git("show", "main:docs/keep.txt"), b"do not delete")
            self.assertEqual(transport.git("show", "main:docs/change.txt"), b"updated\r\n")
            self.assertEqual(transport.git("show", "main:new 中文.bin"), b"\x00\xff\x80\r\n")
            self.assertEqual(transport.git("show", "main:same.txt"), b"hello\n")


if __name__ == "__main__":
    unittest.main()
