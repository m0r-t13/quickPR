import os
from pathlib import Path
import tempfile
import unittest

from quickpr.errors import QuickPRError
from quickpr.files import collect_files, git_blob_sha, normalize_destination, plan_upload


class FilesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def file(self, name, data=b"hello\n"):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def test_git_blob_hash_matches_known_git_object(self):
        self.assertEqual(git_blob_sha(b"hello\n"), "ce013625030ba8dba906f756967f9e9ca394464a")

    def test_directory_contents_keep_relative_paths_and_binary_bytes(self):
        self.file("nested/a.bin", b"\x00\xff")
        batch = collect_files([self.root], destination="assets")
        self.assertEqual([(f.remote_path, f.data) for f in batch.files], [("assets/nested/a.bin", b"\x00\xff")])

    def test_explicit_root_and_overlapping_selections_deduplicate(self):
        f = self.file("nested/a.txt")
        batch = collect_files([f.parent, f], root=self.root)
        self.assertEqual([x.remote_path for x in batch.files], ["nested/a.txt"])

    def test_single_file_does_not_include_absolute_path(self):
        batch = collect_files([self.file("中文 空格/a.txt")], destination="docs")
        self.assertEqual(batch.files[0].remote_path, "docs/a.txt")

    def test_common_parent_preserves_multiple_directories(self):
        a, b = self.file("first/a.txt"), self.file("second/b.txt")
        batch = collect_files([a, b])
        self.assertEqual([x.remote_path for x in batch.files], ["first/a.txt", "second/b.txt"])

    def test_default_and_user_excludes(self):
        for name in [".git/config", "node_modules/a.js", ".venv/a", "keep.txt", "test.log"]:
            self.file(name)
        batch = collect_files([self.root], excludes=["*.log"])
        self.assertEqual([f.remote_path for f in batch.files], ["keep.txt"])
        self.assertTrue(batch.skipped)

    def test_explicit_git_metadata_root_is_never_uploaded(self):
        config = self.file(".git/config", b"private repository configuration")
        with self.assertRaises(QuickPRError):
            collect_files([config], allow_sensitive=True)

    def test_snapshot_keeps_preview_bytes_after_local_edit(self):
        f = self.file("a.txt")
        batch = collect_files([f])
        f.write_bytes(b"changed")
        self.assertEqual(batch.files[0].data, b"hello\n")

    def test_outside_root_is_rejected(self):
        f = self.file("a.txt")
        sub = self.root / "sub"
        sub.mkdir()
        with self.assertRaises(QuickPRError):
            collect_files([f], root=sub)

    def test_paths_reject_traversal_absolute_and_git_metadata(self):
        for value in ["../oops", "/absolute", "C:\\tmp", "x/../a", ".git/objects", "x\nabc"]:
            with self.subTest(value=value), self.assertRaises(QuickPRError):
                normalize_destination(value)
        self.assertEqual(normalize_destination("docs\\images/"), "docs/images")

    def test_sensitive_names_and_private_key_content_blocked(self):
        for name, data in [(".env", b"X=Y"), ("key.txt", b"-----BEGIN OPENSSH PRIVATE KEY-----")]:
            f = self.file(name, data)
            with self.subTest(name=name), self.assertRaises(QuickPRError):
                collect_files([f])
            self.assertEqual(len(collect_files([f], allow_sensitive=True).files), 1)

    def test_symlink_is_not_followed(self):
        f = self.file("original.txt")
        link = self.root / "link.txt"
        try:
            link.symlink_to(f)
        except (OSError, NotImplementedError):
            self.skipTest("This Windows account cannot create symlinks")
        with self.assertRaises(QuickPRError):
            collect_files([link])

    def test_file_size_cap_checked_before_read(self):
        with self.assertRaises(QuickPRError):
            collect_files([self.file("a.txt")], max_file_bytes=2)

    def test_batch_size_cap(self):
        self.file("a.txt")
        self.file("b.txt")
        with self.assertRaises(QuickPRError):
            collect_files([self.root], max_total_bytes=10)

    def test_empty_selection_does_not_upload_anything(self):
        with self.assertRaises(QuickPRError):
            collect_files([])

    def test_plan_new_overwrite_unchanged_and_preserve_remote_mode(self):
        for name in ["new.txt", "same.txt", "run.sh"]:
            self.file(name)
        remote = {
            "same.txt": {"type": "blob", "mode": "100644", "sha": "ce013625030ba8dba906f756967f9e9ca394464a"},
            "run.sh": {"type": "blob", "mode": "100755", "sha": "different"},
        }
        changes = plan_upload(collect_files([self.root]), remote.get)
        self.assertEqual([(c.file.remote_path, c.action, c.mode) for c in changes], [
            ("new.txt", "add", "100644"), ("run.sh", "update", "100755"), ("same.txt", "skip", "100644")])

    def test_plan_rejects_directory_symlink_and_submodule_replacement(self):
        batch = collect_files([self.file("a.txt")])
        for kind, mode in [("tree", "040000"), ("blob", "120000"), ("commit", "160000")]:
            remote = {"a.txt": {"type": kind, "mode": mode, "sha": "x"}}
            with self.subTest(kind=kind), self.assertRaises(QuickPRError):
                plan_upload(batch, remote.get)

    def test_plan_rejects_file_in_parent_directory_position(self):
        batch = collect_files([self.file("a.txt")], destination="docs/deep")
        remote = {"docs": {"type": "blob", "mode": "100644", "sha": "x"}}
        with self.assertRaises(QuickPRError):
            plan_upload(batch, remote.get)


if __name__ == "__main__":
    unittest.main()
