import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from quickpr.picker import pick_files


class Screen:
    """Replace the physical terminal, keeping real picker state and frames."""
    def __init__(self, keys, width=90, height=20):
        self.keys = iter(keys)
        self.width, self.height = width, height
        self.frames = []
        self.entered = self.exited = 0

    def __enter__(self):
        self.entered += 1
        return self

    def __exit__(self, *args):
        self.exited += 1

    def size(self):
        return self.width, self.height

    def render(self, lines):
        self.frames.append(list(lines))

    def read_key(self):
        key = next(self.keys)
        if isinstance(key, BaseException):
            raise key
        return key


class PickerTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.a = self.file("a.txt")
        self.b = self.file("中文 b.txt")

    def file(self, name):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name, encoding="utf-8")
        return path

    def pick(self, keys, **kwargs):
        screen = Screen(keys, **kwargs)
        paths, root = pick_files(self.root, terminal=screen)
        self.assertEqual(root, self.root)
        self.assertEqual((screen.entered, screen.exited), (1, 1))
        return paths, screen

    def test_arrows_move_cursor_and_enter_toggles_file(self):
        paths, screen = self.pick(["enter", "enter", "down", "enter", "f"])
        self.assertEqual(paths, [self.b])
        self.assertTrue(any("[✓] a.txt" in line for line in screen.frames[1]))
        self.assertTrue(any("[ ] a.txt" in line for line in screen.frames[2]))

    def test_up_moves_back_and_no_numbers_are_required(self):
        paths, screen = self.pick(["down", "up", "enter", "f"])
        self.assertEqual(paths, [self.a])

    def test_right_enters_directory_left_restores_parent_cursor(self):
        nested = self.file("folder/inside.txt")
        paths, screen = self.pick(["right", "enter", "left", "down", "enter", "f"])
        self.assertEqual(paths, sorted([self.a, nested]))
        self.assertTrue(any("[-] folder/" in line for frame in screen.frames for line in frame))

    def test_enter_selects_directory_without_entering_it(self):
        self.file("folder/inside.txt")
        paths, screen = self.pick(["enter", "f"])
        self.assertEqual(paths, [self.root / "folder"])

    def test_enter_unchecks_file_selected_by_parent(self):
        inside = self.file("folder/inside.txt")
        self.file("folder/other.txt")
        paths, screen = self.pick(["a", "right", "enter", "f"])
        self.assertEqual(paths, sorted([self.a, self.b, inside.parent / "other.txt"]))

    def test_all_then_clear_and_cancel_returns_no_files(self):
        paths, screen = self.pick(["a", "c", "f", "q"])
        self.assertEqual(paths, [])
        self.assertTrue(any("请先选择" in line for frame in screen.frames for line in frame))

    def test_empty_directory_and_right_on_file_do_not_crash(self):
        (self.root / "empty").mkdir()
        paths, screen = self.pick(["right", "down", "enter", "left", "down", "right", "enter", "f"])
        self.assertEqual(paths, [self.a])

    def test_left_at_root_stays_inside_root(self):
        paths, screen = self.pick(["left", "enter", "f"])
        self.assertEqual(paths, [self.a])

    def test_scroll_keeps_cursor_visible_and_frames_fit_height(self):
        for i in range(45):
            self.file("z{:02}.txt".format(i))
        paths, screen = self.pick(["end", "up", "enter", "f"], height=14)
        self.assertEqual(paths, [self.root / "z44.txt"])
        self.assertTrue(any("z44.txt" in line for line in screen.frames[-1]))
        self.assertTrue(all(len(frame) <= 14 for frame in screen.frames))

    def test_keyboard_interrupt_closes_terminal_session(self):
        screen = Screen([KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt):
            pick_files(self.root, terminal=screen)
        self.assertEqual((screen.entered, screen.exited), (1, 1))

    def test_picker_does_not_print_new_listings_to_stdout(self):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            paths, screen = self.pick(["enter", "down", "enter", "f"])
        self.assertEqual(stdout.getvalue(), "")
        self.assertGreater(len(screen.frames), 1)

    def test_cli_uses_keyboard_picker_in_real_terminal(self):
        from quickpr.cli import select_local
        with patch("quickpr.cli.Terminal.available", return_value=True), \
                patch("quickpr.cli.pick_files", return_value=([self.a], self.root)):
            self.assertEqual(select_local(self.root), ([self.a], self.root))


if __name__ == "__main__":
    unittest.main()
